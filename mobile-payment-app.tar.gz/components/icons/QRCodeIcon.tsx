import React from 'react';

interface QRCodeIconProps {
  size?: number;
  className?: string;
}

export const QRCodeIcon: React.FC<QRCodeIconProps> = ({ 
  size = 24, 
  className = "text-[#428bf9]" 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <g clipPath="url(#clip0_22_2745)">
        <path 
          fillRule="evenodd" 
          clipRule="evenodd" 
          d="M6 1H1V5.5H1.5C2.3 5.5 3 4.8 3 4V3H4.5C5.3 3 6 2.3 6 1.5V1ZM7 7H11V11H7V7ZM5 5H7H11H13V7V11V13H11H7H5V11V7V5ZM13 13H15H17H19V15V17V19H17H15H13V17V15V13ZM17 15H15V17H17V15ZM6 23H1V18.5H1.5C2.3 18.5 3 19.2 3 20V21H4.5C5.3 21 6 21.7 6 22.5V23ZM23 1H18V1.5C18 2.3 18.7 3 19.5 3H21V4C21 4.8 21.7 5.5 22.5 5.5H23V1ZM18 23H23V18.5H22.5C21.7 18.5 21 19.2 21 20V21H19.5C18.7 21 18 21.7 18 22.5V23ZM19 11V5H17H15V7H17V9H15V11H17H19ZM11 15H5V17V19H7V17H9V19H11V17V15ZM9.75 8.25H8.25V9.75H9.75V8.25Z" 
          fill="currentColor"
        />
      </g>
      <defs>
        <clipPath id="clip0_22_2745">
          <rect width="24" height="24" fill="white"/>
        </clipPath>
      </defs>
    </svg>
  );
};
